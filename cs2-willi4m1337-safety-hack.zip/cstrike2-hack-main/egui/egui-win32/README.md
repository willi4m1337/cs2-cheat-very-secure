# Egui Win32

Windows32 input handler for egui;
Takes input from windows api , WndProc and converts it into egui compatible RawInput

## Sources
https://crates.io/crates/egui-d3d9
https://crates.io/crates/egui-d3d11